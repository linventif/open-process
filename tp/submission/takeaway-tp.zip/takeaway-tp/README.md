# TakeAway TP deliverables

- [Final PDF report](report/rapport-final.pdf)
- [HTML report and figures](report/rapport-final.html)
- [Delivery checklist](PLAN.md)
- [Reproduction instructions](REPRODUCE.md)
- [Recorded checks](results/verification.json)
- [BPMN evidence](results/bpmn/evidence.json) and [validation](results/bpmn/validation.json)

Editable .opx, standard .bpmn and vector .svg models are in results/bpmn/. The three corrected CSVs in clean/ are the authoritative behavioral inputs. Supplied originals and complementary workbooks are preserved. Independent analysis assets are in report/analysis/. package-manifest.json lists every contained file and its SHA-256.
